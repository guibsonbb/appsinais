# ꧁ঔৣ☬ 🅺🆁🅰🆃🅾🆂🆈 ☬ঔৣ꧂

Copyright (c) 2021 Kratosy.

[+] Descrição: Kratosy, a ferramenta para consulta, trata-se de um sistema avançado, em Python, que ”puxa" dados de: IP, nome, CPF, CEP, CNPJ, placa e telefone.

Os scripts possuem características autorais e, seu uso para quaisquer meios sem vínculo pedagógico ou educacional, é proibido. Não possui intenção comercial, portanto, não está a venda dos direitos.

[+] As informações obtidas: IP: Seu endereço de IP; Cidade; Região; País; Abreviação do país; Capital do país; População do país; Moeda; Nome da moeda; Código da região; Código postal; Código do país; Código do país ISO3; Área do país; País TLD; Código área; Código do continente; União Européia; Latitude; Longitude; Fuso horário; Código de Chamada; línguas; ASN; ORG; Deslocamento UTF; Versão; Link localização Google Maps;

Nome: Busca nome (Encontra nome completo); Consultar nome (Encontra CPF e data de nascimento);

CPF: Nome completo; Data de nascimento; Nome da Mae; Endereço; Complemento; Bairro; Cidade; CEP; Gera e valida CPF;

CEP: ENDEREÇO; COMPLEMENTO; BAIRRO; CIDADE; ESTADO; IBGE; GIA; DDD; SIAFI;

CNPJ: Completo. (100%)

Placa: Ano; Data; Modelo; Ano do modelo; Cor; Marca; Roubo/furto; Situação; Chassi; UF; Município; Modificada em; Alarme atualizado; Mensagem de retorno; Código de retorno;

Telefone: Formato internacional; Formato local; País; Cidade/Estado; Operadora; Fuso horário; Validação; Scan com Numverify.com; Operadora; Tipo de linha;

[+] Instalação: Para instalar no seu Termux, siga os comandos:

apt update && apt upgrade apt instala python pkg install git git clone https://github.com/Kratosy/Puxar-Dados-Termux ls cd snuking python install.py python consulta.py

© Kratosy, 2021
